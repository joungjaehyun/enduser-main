import MemberModifyComponent from "../../components/member/MemberModifyComponent"

const MemberModifyPage = () => {


    

    return ( 
        <div>
            <div>
                
                Member Modify Page
                <MemberModifyComponent></MemberModifyComponent>
                    
            </div>
        </div>
    );
}
 
export default MemberModifyPage;