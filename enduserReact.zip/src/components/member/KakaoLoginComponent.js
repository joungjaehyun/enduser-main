// import { Link } from "react-router-dom";

// const REST_KEY = '6f4e3dc1bc490e8e161bcf59dd0aa57f'
// const REDIRECT_URI ='http://localhost:3000/member/kakao'

// const kakaoURL =`https://kauth.kakao.com/oauth/authorize?client_id=${REST_KEY}&redirect_uri=${REDIRECT_URI}&response_type=code`

// const KakaoLoginComponent = () => {

//     return ( 
//         <div className="text-2xl text-white bg-yellow-500 m-auto p-2 w-44 text-center border-2 rounded-full">
//             <Link to={kakaoURL}>
//                 KAKAO LOGIN
//             </Link>
//         </div>
//      );
// }
 
// export default KakaoLoginComponent;