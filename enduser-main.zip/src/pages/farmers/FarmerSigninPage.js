import FarmerSiginComponent from "../../components/farmers/FarmerSigninComponent";

const FarmerSigninPage = () => {
    return (  
        <div>
            FarmerLoginPage
            
            <FarmerSiginComponent></FarmerSiginComponent>
        </div>
    );
}
 
export default FarmerSigninPage;