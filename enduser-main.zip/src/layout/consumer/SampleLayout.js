//import styles from "../../styles.css";

import FooterComponent from "../../components/consumer/FooterComponent";
import HeaderComponent from "../../components/consumer/HeaderComponent";


const SampleLayout = () => {

    return ( 
        
        <div className="container mx-[auto] w-[1280px] bg-oy-01">
            <div>
                <HeaderComponent></HeaderComponent>
                
            </div>
        </div>
       
     );

}
 
export default SampleLayout;