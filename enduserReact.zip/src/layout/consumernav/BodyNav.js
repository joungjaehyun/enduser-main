const BodyNav = () => {
    
    return ( 
        <div className="container text-center font-extrabold">
            <div className="text-2xl">공지</div>
        </div>
        
     );
}
 
export default BodyNav;